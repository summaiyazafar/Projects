# 🤖 Live AI Assistant (ChatGPT Style)

An advanced AI Assistant built using **Streamlit + LangChain + Web Search + Memory System**.  
It can answer questions using real-time internet data and remembers chat history.

---

## ✨ Features

- 💬 Live AI Agent
- 🌐 Live Web Search (Tavily API)
- 🧠 Memory (conversation history)
- 🔐 Sidebar controls (Sign In / Sign Up UI)
- 🚀 Clean modern interface
- ⚡ Real-time AI responses

---

## 🛠️ Tech Stack

- Python
- Streamlit
- LangChain
- OpenAI / Groq LLM
- Tavily Search API

---

## 📦 Installation

```bash
pip install -r requirements.txt