Project Name: Benazir Kafaalat Eligibility Assistant

Description:
This project is a Retrieval Augmented Generation (RAG) chatbot built using:
- LangChain
- Pinecone
- Groq Llama 3
- HuggingFace Embeddings
- Gradio

Features:
- Answers questions from uploaded Benazir Kafaalat documents.
- Supports Urdu and English queries.
- Uses vector search with Pinecone.